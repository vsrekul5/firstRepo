// A collection of musicians where the key is the unique id
module.exports = {
  coltrane: {
    firstName: 'John',
    lastName: 'Coltrane',
    genre: 'JAZZ',
  },

  davis: {
    firstName: 'Gustav',
    lastName: 'Ejstes',
    genre: 'Rock',
  },

  mccartney: {
    firstName: 'Paul',
    lastName: 'McCartney',
    genre: 'ROCK',
  },

  hendrix: {
    firstName: 'Jimi',
    lastName: 'Hendrix',
    genre: 'Rock',
  },

  cobain: {
    firstName: 'Kurt',
    lastName: 'Cobain',
    genre: 'Rock',
  },

  king: {
    firstName: 'Bo',
    lastName: 'Hansson',
    genre: 'Rock',
  },
};
